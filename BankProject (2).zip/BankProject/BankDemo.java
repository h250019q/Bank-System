import java.util.ArrayList;
import java.util.List;

public class BankDemo {
    public static void main(String[] args) {
        List<Account> accounts = new ArrayList<>();
        accounts.add(new SavingsAccount("SAV-001", 1000.00));
        accounts.add(new SavingsAccount("SAV-002", 300.00));
        accounts.add(new CurrentAccount("CUR-001", 200.00));
        accounts.add(new CurrentAccount("CUR-002", 100.00));

        System.out.println("=== Deposit check ===");
        accounts.get(0).deposit(-50);

        System.out.println("\n=== Withdraw 250.00 from every account ===");
        for (Account acc : accounts) {
            acc.withdraw(250.00);
            System.out.printf("%s balance: %.2f%n", acc.getAccountNumber(), acc.getBalance());
        }

        System.out.println("\n=== Edge case: overdraft limit exceeded ===");
        Account overdrawn = accounts.get(3); // CUR-002
        overdrawn.withdraw(400.00);
        System.out.printf("%s balance: %.2f%n", overdrawn.getAccountNumber(), overdrawn.getBalance());

        System.out.println("\n=== End of month processing ===");
        for (Account acc : accounts) {
            acc.endOfMonth();
        }
    }
}