public class CurrentAccount extends Account {
    private final double overdraftLimit = 500.0;
    private final double monthlyFee = 10.0;

    public CurrentAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    @Override
    public void withdraw(double amount) {
        if (balance - amount < -overdraftLimit) {
            System.out.printf("%s: Withdrawal of %.2f rejected. Overdraft limit of %.2f would be exceeded%n",
                    accountNumber, amount, overdraftLimit);
        } else {
            balance = balance - amount;
            if (balance < 0) {
                System.out.printf("%s: Withdrew %.2f (account is now overdrawn)%n", accountNumber, amount);
            } else {
                System.out.printf("%s: Withdrew %.2f%n", accountNumber, amount);
            }
        }
    }

    @Override
    public void endOfMonth() {
        balance = balance - monthlyFee;
        System.out.printf("%s: Maintenance fee charged: %.2f -> balance %.2f%n",
                accountNumber, monthlyFee, balance);
    }
}