public class SavingsAccount extends Account {
    private final double minimumBalance = 100.0;
    private final double interestRate = 0.02; // 2% per month

    public SavingsAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    @Override
    public void withdraw(double amount) {
        if (balance - amount < minimumBalance) {
            System.out.printf("%s: Withdrawal of %.2f rejected. Balance cannot fall below the minimum of %.2f%n",
                    accountNumber, amount, minimumBalance);
        } else {
            balance = balance - amount;
            System.out.printf("%s: Withdrew %.2f%n", accountNumber, amount);
        }
    }

    @Override
    public void endOfMonth() {
        double interest = balance * interestRate;
        balance = balance + interest;
        System.out.printf("%s: Interest added: %.2f -> balance %.2f%n",
                accountNumber, interest, balance);
    }
}